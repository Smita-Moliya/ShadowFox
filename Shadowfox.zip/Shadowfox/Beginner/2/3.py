distance = 490
time_seconds = 7 * 60
speed = distance / time_seconds
print("Speed in meters per second:", int(speed))
