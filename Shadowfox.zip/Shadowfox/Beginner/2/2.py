pi = 3.14
radius = 84
area = pi * radius ** 2
water_per_sq_meter = 1.4
total_water = area * water_per_sq_meter
print("Area of pond:", area)
print("Total water in the pond (liters):", int(total_water))
