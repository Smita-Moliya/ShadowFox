number = 145
formatted = format(number, 'o')
print("Formatted result:", formatted)
