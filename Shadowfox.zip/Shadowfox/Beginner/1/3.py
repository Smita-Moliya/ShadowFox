# Assign values
principal = 10000  # Example value
rate = 5           # Interest rate in percent
time = 3           # Time in years

# Calculate simple interest
simple_interest = (principal * rate * time) / 100

# Output the result
print("Simple Interest:", simple_interest)
