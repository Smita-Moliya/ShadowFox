pi = 22 / 7
print("Value of pi:", pi)
print("Data type of pi:", type(pi))
